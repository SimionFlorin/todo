// import { connect } from 'react-redux'
// import { dispatch } from 'rxjs/internal/observable/range';
// import { updateTaskStatus } from '../actions';
// import Task from './../components/Task';



// const mapDispatchToProps = dispatch => ({
//     updateTaskStatusDispatch: (id,status)=>dispatch(updateTaskStatus(id,status))
// })

// export default
// connect(mapDispatchToProps)(Task)
